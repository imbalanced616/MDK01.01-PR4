﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Fossils.Classes;
using Excel = Microsoft.Office.Interop.Excel;

namespace Fossils.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageSales.xaml
    /// </summary>
    public partial class PageSales : Page
    {
        public PageSales()
        {
            InitializeComponent();
            DtgSQLS.ItemsSource = MiningFossilsEntities.GetContext().Sales.ToList();
        }

        private void MenuAddSale_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new AddPageSales(null));
        }

        private void MenuEditSale_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new AddPageSales((Sales)DtgSQLS.SelectedItem));
        }

        private void MenuDelSale_Click(object sender, RoutedEventArgs e)
        {
            var salesForRemoving = DtgSQLS.SelectedItems.Cast<Sales>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {salesForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    MiningFossilsEntities.GetContext().Sales.RemoveRange(salesForRemoving);
                    MiningFossilsEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    DtgSQLS.ItemsSource = MiningFossilsEntities.GetContext().Sales.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnTransitionDeposits_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageDeposits());
        }

        private void BtnTransitionFossils_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageFossils());
        }

        private void MenuUpdateSales_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLS.ItemsSource = MiningFossilsEntities.GetContext().Sales.ToList();
            txbSearchFossil.Clear();
            spSearchFossil.Visibility = Visibility.Hidden;
            MenuSearch.Header = "Поиск";
        }

        private void MenuSortCostFossil1_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLS.ItemsSource = MiningFossilsEntities.GetContext().Sales.OrderBy(x => x.FossilsBD.Fossil).ToList();
        }

        private void MenuSortCostFossil2_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLS.ItemsSource = MiningFossilsEntities.GetContext().Sales.OrderByDescending(x => x.FossilsBD.Fossil).ToList();
        }

        private void MenuSortFiltСlear_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLS.ItemsSource = MiningFossilsEntities.GetContext().Sales.ToList();
        }

        private void MenuFilterPPU1_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLS.ItemsSource = MiningFossilsEntities.GetContext().Sales.Where(x => x.PricePerUnit >= 0 && x.PricePerUnit <= 100).ToList();
        }

        private void MenuFilterPPU2_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLS.ItemsSource = MiningFossilsEntities.GetContext().Sales.Where(x => x.PricePerUnit >= 101 && x.PricePerUnit <= 200).ToList();
        }

        private void MenuFilterPPU3_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLS.ItemsSource = MiningFossilsEntities.GetContext().Sales.Where(x => x.PricePerUnit >= 201 && x.PricePerUnit <= 300).ToList();
        }

        private void MenuFilterPPU4_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLS.ItemsSource = MiningFossilsEntities.GetContext().Sales.Where(x => x.PricePerUnit >= 301 && x.PricePerUnit <= 400).ToList();
        }

        private void MenuFilterPPU5_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLS.ItemsSource = MiningFossilsEntities.GetContext().Sales.Where(x => x.PricePerUnit >= 401).ToList();
        }

        private void MenuSearch_Click(object sender, RoutedEventArgs e)
        {
            if (spSearchFossil.Visibility == Visibility.Hidden)
            {
                spSearchFossil.Visibility = Visibility.Visible;
                MenuSearch.Header = "Убрать поиск";
            }
            else
            {
                txbSearchFossil.Clear();
                spSearchFossil.Visibility = Visibility.Hidden;
                MenuSearch.Header = "Поиск";
            }
        }

        private void txbSearchFossil_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DtgSQLS.ItemsSource != null) DtgSQLS.ItemsSource = MiningFossilsEntities.GetContext().Sales.Where(x => x.FossilsBD.Fossil.ToLower().Contains(txbSearchFossil.Text.ToLower())).ToList();
            if (txbSearchFossil.Text.Count() == 0) DtgSQLS.ItemsSource = MiningFossilsEntities.GetContext().Sales.ToList();
        }

        private void MenuExportToExcelSale_Click(object sender, RoutedEventArgs e)
        {
            var app = new Excel.Application();
            Excel.Workbook wb = app.Workbooks.Add();
            Excel.Worksheet worksheet = app.Worksheets.Item[1];
            int IndexRows = 1;
            worksheet.Cells[1][IndexRows] = "№";
            worksheet.Cells[2][IndexRows] = "Наименование ископаемого";
            worksheet.Cells[3][IndexRows] = "Себестоимость";
            worksheet.Cells[4][IndexRows] = "Цена с наценкой";
            Excel.Range headerRange = worksheet.Range[worksheet.Cells[1][1], worksheet.Cells[4][1]];
            headerRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
            headerRange.Font.Bold = true;
            headerRange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
            headerRange.Borders.Weight = Excel.XlBorderWeight.xlThin;

            List<Sales> printItems = new List<Sales>();
            for (int i = 0; i < DtgSQLS.Items.Count; i++) printItems.Add((Sales)DtgSQLS.Items[i]);
            foreach (var item in printItems)
            {
                worksheet.Cells[1][IndexRows + 1] = IndexRows;
                worksheet.Cells[2][IndexRows + 1] = item.FossilsBD.Fossil;
                worksheet.Cells[3][IndexRows + 1] = item.CostPerUnit;
                worksheet.Cells[4][IndexRows + 1] = item.PricePerUnit;
                IndexRows++;

                Excel.Range bodyRange = worksheet.Range[worksheet.Cells[1][IndexRows], worksheet.Cells[4][IndexRows]];
                bodyRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
                bodyRange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
                bodyRange.Borders.Weight = Excel.XlBorderWeight.xlThin;

                Excel.Range numbersRange = worksheet.Range[worksheet.Cells[2, 1], worksheet.Cells[IndexRows, 1]];
                numbersRange.Font.Italic = true;
            }
            worksheet.Name = "Продажи";
            worksheet.Columns.AutoFit();
            worksheet.Rows.AutoFit();
            app.Visible = true;
        }
    }
}
